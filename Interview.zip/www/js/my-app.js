// Initialize app
var myApp = new Framework7();


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
    var today = new Date();
    var currentdate = (today.getDate() < 10 ? ("0"+today.getDate()) : (today.getDate()))+"/"+((today.getMonth()+1) < 10 ? ("0"+(today.getMonth()+1)) : (today.getMonth()+1))+"/"+(today.getFullYear());
    $$("#currentdate").html(currentdate);
    var comment = JSON.parse(localStorage.getItem("commentdata"));
    console.log(comment);
    $$.each(comment, function (key, val){
      $$("#usercommentbox").append('<li>'+
            '<div class="item-content">'+
                '<div class="item-media"><img src="img/user.jpg" width="44"></div>'+
                '<div class="item-inner">'+
                  '<div class="item-title-row">'+
                    '<div class="item-title">User</div>'+
                    '<div class="item-after">'+currentdate+'</div>'+
                  '</div>'+
                  '<div class="item-subtitle">'+val+'</div>'+
                '</div>'+
            '</div></li>');
    });
});

function submitcomment() {
    var today = new Date();
    var currentdate = (today.getDate() < 10 ? ("0"+today.getDate()) : (today.getDate()))+"/"+((today.getMonth()+1) < 10 ? ("0"+(today.getMonth()+1)) : (today.getMonth()+1))+"/"+(today.getFullYear());
    var uservalue = document.getElementById("usercomment").value;
    console.log(uservalue);
    var commentdata = JSON.parse(window.localStorage.getItem("commentdata"));
    if(commentdata) {
        commentdata = commentdata;
    } else {
        commentdata = [];
    }
    if(uservalue) {
        commentdata.push(uservalue);
        window.localStorage.setItem("commentdata", JSON.stringify(commentdata));
        console.log(commentdata);
        $$("#usercommentbox").append('<li>'+
            '<div class="item-content">'+
                '<div class="item-media"><img src="img/user.jpg" width="44"></div>'+
                '<div class="item-inner">'+
                  '<div class="item-title-row">'+
                    '<div class="item-title">User</div>'+
                    '<div class="item-after">'+currentdate+'</div>'+
                  '</div>'+
                  '<div class="item-subtitle">'+uservalue+'</div>'+
                '</div>'+
            '</div></li>');
        $$("#usercomment").val('');
    } else {
        myApp.alert("Please comment.");
    }
}

myApp.onPageInit('interview', function (page) {
    var like = window.localStorage.getItem("likecount");
    $$('#likecount').html(like);
    var comment = window.localStorage.getItem("commentcount");
    $$('#commentcount').html(comment);
    var comment = JSON.parse(localStorage.getItem("commentdata"));
    console.log(comment);
    $$.each(comment, function (key, val){
      $$("#commentbox").append('<li class="item-content"><div class="item-inner" style="padding:0;"><div class="item-title">'+val+'</div></div></li>');
    });

    $$('.likes').on('click', function () {
      var like = window.localStorage.getItem("likecount") ? window.localStorage.getItem("likecount") : 0;
      var likes = (parseInt(like) + 1);
      window.localStorage.setItem("likecount", likes);
      $$('#likecount').html(likes);
    });
    $$('.comments').on('click', function () {
      $$('#comment').focus();
    });
})

function submit(e) {
    if (e.keyCode == 13) {
      var tb = document.getElementById("comment");
      console.log(tb.value);
      var commentdata = JSON.parse(window.localStorage.getItem("commentdata"));
      if(commentdata) {
        commentdata = commentdata;
      } else {
        commentdata = [];
      }
      if(tb.value) {
        var comment = window.localStorage.getItem("commentcount") ? window.localStorage.getItem("commentcount") : 0;
        var comments = (parseInt(comment) + 1);
        window.localStorage.setItem("commentcount", comments);
        $$('#commentcount').html(comments);
        commentdata.push(tb.value);
        window.localStorage.setItem("commentdata", JSON.stringify(commentdata));
        console.log(commentdata);
        $$("#commentbox").append('<li class="item-content"><div class="item-inner" style="padding:0;"><div class="item-title">'+tb.value+'</div></div></li>');
        $$("#comment").val('');
      } else {
        myApp.alert("Please comment.");
      }
      //return false;
    }
}

// Now we need to run the code that will be executed only for About page.

// Option 1. Using page callback for page (for "about" page in this case) (recommended way):
myApp.onPageInit('about', function (page) {
    // Do something here for "about" page

})

// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    // Get page data from event data
    var page = e.detail.page;

    if (page.name === 'about') {
        // Following code will be executed for page with data-page attribute equal to "about"
        myApp.alert('Here comes About page');
    }
})

// Option 2. Using live 'pageInit' event handlers for each page
$$(document).on('pageInit', '.page[data-page="about"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
    myApp.alert('Here comes About page');
})