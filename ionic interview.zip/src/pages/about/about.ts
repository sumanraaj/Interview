import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  params: Object;
  pushPage: any;
  itemsRef: Observable<any[]>;

  constructor(public navCtrl: NavController) {
    this.params = { id:100 };
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AboutPage');
    
  }

}
