import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';

import { Observable } from 'rxjs/Observable';

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  items= [];
  commentdata= [];
  //itemsRef: Observable<any[]>;
  admin:any;
  currentdate:any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public checkLog: AuthServiceProvider, public alertCtrl: AlertController) {
  
  }

  ionViewDidLoad() {
    var today = new Date();
    var currentdate = (today.getDate() < 10 ? ("0"+today.getDate()) : (today.getDate()))+"/"+((today.getMonth()+1) < 10 ? ("0"+(today.getMonth()+1)) : (today.getMonth()+1))+"/"+(today.getFullYear());
    this.currentdate=currentdate;
    var comment = JSON.parse(localStorage.getItem("commentdata"));
    console.log(comment);
    this.items = comment;
  }

  onSubmit(commentform) {
    var userData = commentform.value;
    var today = new Date();
    var currentdate = (today.getDate() < 10 ? ("0"+today.getDate()) : (today.getDate()))+"/"+((today.getMonth()+1) < 10 ? ("0"+(today.getMonth()+1)) : (today.getMonth()+1))+"/"+(today.getFullYear());
    var uservalue = userData.COMMENT;
    console.log(uservalue);
    var commentdata = JSON.parse(localStorage.getItem("commentdata"));
    if(commentdata) {
        commentdata = commentdata;
    } else {
        commentdata = [];
    }
    if(uservalue) {
      commentdata.push(uservalue);
      localStorage.setItem("commentdata", JSON.stringify(commentdata));
      console.log(commentdata);
      this.items = commentdata;
      commentform.value.COMMENT = '';
    } else {
      alert("Please comment.");
    }
  }

}
